package hu.hwsw.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;

@EnableDiscoveryClient
@SpringBootApplication
public class GatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(GatewayApplication.class, args);
    }

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()
                .route("airport-service", r -> r.path("/airports/**")
                        .filters(f -> f.rewritePath("/airports/(?<segment>.*)", "/api/v1/airports/${segment}"))
                        .uri("lb://airport-service"))
                .route("user-service", r -> r.path("/users/login")
                        .filters(f -> f.rewritePath("/users/login", "/login"))
                        .uri("lb://user-service"))
                .route("user-service", r -> r.path("/users/**")
                        .filters(f -> f.rewritePath("/users/(?<segment>.*)", "/api/v1/users/${segment}"))
                        .uri("lb://user-service"))
                .build();
    }

}
