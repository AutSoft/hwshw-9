package hu.hwsw.airportapp.airport.web;

import hu.hwsw.airport.dto.airport.AirportDTO;
import hu.hwsw.airport.dto.airport.NewAirportDTO;
import hu.hwsw.airportapp.airport.mapper.AirportMapper;
import hu.hwsw.airportapp.airport.model.Airport;
import hu.hwsw.airportapp.airport.repository.AirportRepository;
import hu.hwsw.airportapp.airport.service.AirportService;
import hu.hwsw.airportapp.user.dto.UserDTO;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/airports")
public class AirportController {

	private final AirportService airportService;
	private final AirportRepository airportRepository;
	
	public AirportController(AirportService airportService, AirportRepository airportRepository) {
		super();
		this.airportService = airportService;
		this.airportRepository = airportRepository;
	}

	@GetMapping("/protected")
	AirportDTO protectedData() {
		String username = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		return mapAirportToDto(airportService.getProtectedDataByUser(username));
	}

	@GetMapping
	List<AirportDTO> getAirports(@RequestParam(name = "iata", required = false) String iata, Pageable pageable) {
		return airportService.getAirports(iata, pageable)
				.stream()
				.map(airport -> mapAirportToDto(airport))
				.collect(Collectors.toList());
	}


	private AirportDTO mapAirportToDto(Airport airport) {
		return new AirportDTO(airport.getId(), airport.getCreatedAt(), airport.getModifiedAt(), airport.getName(), airport.getIata());
	}

	@PostMapping
	AirportDTO createAirport(@RequestBody @Valid NewAirportDTO newAirport) {
		return mapAirportToDto(airportService.createAirport(newAirport));
	}

	@GetMapping("/{id}")
	ResponseEntity<AirportDTO> getAirportById(@PathVariable Long id) {
	    return ResponseEntity
	    		.status(HttpStatus.OK)
	    		.body(mapAirportToDto(airportService.getAirportById(id)));

	}

	@PutMapping("/{id}")
	AirportDTO updateAirport(@PathVariable Long id, @RequestBody @Valid NewAirportDTO newAirport) {
		return AirportMapper.INSTANCE.airportToDto(airportService.updateAirport(id, newAirport));
	}

	@ResponseStatus(HttpStatus.NO_CONTENT)
	@DeleteMapping("/{id}")
	public void deleteAirport(@PathVariable Long id) {
		airportRepository.deleteById(id);
	}
}
