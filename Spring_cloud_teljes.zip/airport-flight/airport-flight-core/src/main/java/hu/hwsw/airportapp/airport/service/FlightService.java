package hu.hwsw.airportapp.airport.service;

import hu.hwsw.airportapp.airport.model.Flight;
import hu.hwsw.airport.dto.flight.NewFlightDTO;
import hu.hwsw.airport.dto.flight.NewFlightWithNewAirportsDTO;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.util.List;

@Service
public interface FlightService {
    List<Flight> getArrivingFlightsByAirportId(Long airportId);

    List<Flight> getDepartingFlightsByAirportId(Long airportId);

    Flight createFlight(@Valid NewFlightDTO newFlight);

    List<Flight> getFlights();

    Flight getFlightById(Long id);

    Flight updateFlightById(Long id, NewFlightDTO newFlight);

    void deleteFlightById(Long id);

	Flight createFlightWithAirports(NewFlightWithNewAirportsDTO newFlightWithNewAirportsDTO);
	
	List<Flight> searchFlights(Flight flight);
}
