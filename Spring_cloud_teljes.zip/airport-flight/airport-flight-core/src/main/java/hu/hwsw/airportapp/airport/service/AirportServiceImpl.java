package hu.hwsw.airportapp.airport.service;

import hu.hwsw.airport.dto.airport.NewAirportDTO;
import hu.hwsw.airportapp.airport.mapper.AirportMapper;
import hu.hwsw.airportapp.airport.model.Airport;
import hu.hwsw.airportapp.airport.repository.AirportRepository;
import hu.hwsw.airportapp.user.client.UserClient;
import hu.hwsw.airportapp.user.dto.UserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.transaction.Transactional;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
public class AirportServiceImpl implements AirportService {
	
	@Autowired
	AirportRepository airportRepository;

	@Autowired
	UserClient userClient;

	@Override
	public List<Airport> getAirports(String iata, Pageable pageable) {
		
		if (StringUtils.isEmpty(iata)) {
			return airportRepository.findAll(pageable).getContent();
		} else {
			return airportRepository.findByIata(iata, pageable).getContent();
		}
		
	}

	@Override
	public Airport createAirport(NewAirportDTO newAirport) {
		Airport airport = new Airport();
		airport.setIata(newAirport.getIata());
		airport.setName(newAirport.getName());
		return airportRepository.save(airport);
	}
	
	@Override
	public Airport getAirportById(Long id) {
		Optional<Airport> airportOptional = airportRepository.findById(id);

		if (airportOptional.isEmpty()) {
			throw new NoSuchElementException(String.format("Airport not found with id %d", id));
		}

		return airportOptional.get();
	}

	@Override
	@Transactional
	public Airport updateAirport(Long id, NewAirportDTO newAirport) {
		Airport airport = getAirportById(id);
		AirportMapper.INSTANCE.updateFromDto(newAirport, airport);
		return airport;
	}

	@Override
	public Airport getProtectedDataByUser(String username) {
		UserDTO user = userClient.getUserByUsername(username);
		if(user.isEnabled()) {
			Airport airport =  new Airport();
			airport.setName("Katonai reptér");
			return airport;
		}
		throw new AccessDeniedException("A felhasználónak nincs joga lekérni a védett adatot");
	}

}
