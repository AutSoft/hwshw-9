package hu.hwsw.airportapp.airport.mapper;

import hu.hwsw.airportapp.airport.model.Flight;
import hu.hwsw.airport.dto.flight.FlightDTO;
import hu.hwsw.airport.dto.flight.NewFlightDTO;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface FlightMapper {

	FlightMapper INSTANCE = Mappers.getMapper(FlightMapper.class);
	
	FlightDTO flightToDto(Flight flight);
	
	List<FlightDTO> flightsToDto(List<Flight> flight);
	
	void updateFromDto(NewFlightDTO dto, @MappingTarget Flight flight);

	Flight dtoToFlight(FlightDTO example);
}
