package hu.hwsw.airportapp.airport.service;

import hu.hwsw.airportapp.airport.model.Airport;
import hu.hwsw.airport.dto.airport.NewAirportDTO;
import hu.hwsw.airportapp.user.dto.UserDTO;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface AirportService {

	List<Airport> getAirports(String iata, Pageable pageable);

	Airport createAirport(NewAirportDTO newAirport);

	Airport getAirportById(Long id);

	Airport updateAirport(Long id, NewAirportDTO newAirport);

	Airport getProtectedDataByUser(String username);
}
