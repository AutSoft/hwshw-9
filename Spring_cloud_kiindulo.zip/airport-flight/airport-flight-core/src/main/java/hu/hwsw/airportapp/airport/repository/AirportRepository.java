package hu.hwsw.airportapp.airport.repository;

import hu.hwsw.airportapp.airport.model.Airport;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AirportRepository extends JpaRepository<Airport, Long>{
	
	Page<Airport> findByIata(String iata, Pageable pageable);

}
